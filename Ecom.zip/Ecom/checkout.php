<?php
include_once("./db.php");
session_start();
class order{
    public $pid;
    public $qty;
}
if(isset($_POST["login_user_with_product"])){
    $userid = $_SESSION["uid"];
    $ord = array();
    $sql = "select p_id, qty from cart where user_id = $userid";
    $orderid = "black";
    $query = mysqli_query($con,$sql);
    if (mysqli_num_rows($query) > 0) {
        while ($row=mysqli_fetch_array($query)) {
            $o = new order;
            $o->pid = $row["p_id"];
            $o->qty = $row["qty"];
            array_push($ord, $o);
        }
    }
    $sql = "SELECT max(order_id)+1 as id FROM orders";
    if($query = mysqli_query($con,$sql)){
        if (mysqli_num_rows($query) > 0) {
            $row = mysqli_fetch_array($query);
            $orderid = $row["id"];
            if($orderid == "")
                $orderid = 1;
            //echo "here is orderid: ".$orderid;
        }else{
            //echo "-----";
        }    
    }else
        echo "Not running";
    foreach($ord as $o){
        $sql = "insert into orders (order_id, user_id, product_id, qty) values ($orderid, $userid, $o->pid, $o->qty)";
        if(mysqli_query($con,$sql))
        {
            //echo " done ";
        }
        else
        {
            //echo " not done ";
        }
    }
    header("Location: profile.php");
}
?>