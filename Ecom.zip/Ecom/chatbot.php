<?php 
    include_once("./db.php"); 
    class product{
        public $title;
        public $price;
    }
    $prods = array();
?>
<?php
    $intent = "";
    $reply = "";

    if(isset($_POST["submit"]) && !empty($_POST["message"])){
        $witRoot = "https://api.wit.ai/message?";
        $witVersion = "20190330";
        $query = "what is the price of galaxy note 2";
        $query = $_POST["message"];
        $input_utterance = "";
        for($i = 0; $i < strlen($query); ++$i){
            if($query[$i] == ' '){
                $input_utterance .= "%20";
            }else{
                $input_utterance .= $query[$i];
            }
        }
        //$input_utterance = 'what%20is%20the%20price%20of%20galaxy%20note%202';
        $witURL = $witRoot . "v=" . $witVersion . "&q=" . $input_utterance;

        $ch = curl_init();
        $header = array();
        $header[] = "Authorization: Bearer 4GDFB3PBUKAJ5U4K45IIULCSZSIYUPGE";

        curl_setopt($ch, CURLOPT_URL, $witURL);
        curl_setopt($ch, CURLOPT_POST, 1);  //sets method to POST (1 = TRUE)
        curl_setopt($ch, CURLOPT_HTTPHEADER,$header); //sets the header value above - required for wit.ai authentication
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); //inhibits the immediate display of the returned data

        $server_output = curl_exec ($ch); //call the URL and store the data in server_output
        //echo $server_output;
        $jObj = json_decode($server_output);
        if (property_exists($jObj->{"entities"}, "intent")) {
            $intent = $jObj->{"entities"}->{"intent"}[0]->{"value"};
            
            
            //get the price of the product 
            if($intent === "get_price"){                                
                if (property_exists($jObj->{"entities"}, "product")) {
                    $prod = $jObj->{"entities"}->{"product"}[0]->{"value"};
                    $sql = "select product_title as title, product_price as price from products where product_title like \"%$prod%\"";
                    $query = mysqli_query($con,$sql);
                    if (mysqli_num_rows($query) > 0) {
                        while ($row=mysqli_fetch_array($query)) {
                            $o = new product;
                            $o->title = $row["title"];
                            $o->price = $row["price"];
                            array_push($prods, $o);
                        }
                        $reply = "<table><tr><th>Product</th><th>Price</th></tr>";
                        foreach($prods as $o){
                            $reply .= "<tr>";
                            $reply .= "<td>".$o->title."</td>";
                            $reply .= "<td>".$o->price."</td>";
                            $reply .= "</tr>";
                        }
                        $reply .= "</table>";
                    }else{
                        $reply = "Please use the search bar to search for the product to get price";
                    }
                }else{
                    $reply = "Please use the search bar to search for the product to get price";
                }
            }
            
            
            //get the availability of the product 
            if($intent === "is_available"){
                if (property_exists($jObj->{"entities"}, "product")) {
                    $prod = $jObj->{"entities"}->{"product"}[0]->{"value"};
                    
                    $sql = "select product_title as title, product_qty as qty from products where product_title like \"%$prod%\"";
                    $query = mysqli_query($con,$sql);
                    if (mysqli_num_rows($query) > 0) {
                        while ($row=mysqli_fetch_array($query)) {
                            $o = new product;
                            $o->title = $row["title"];
                            $o->price = $row["qty"];
                            array_push($prods, $o);
                        }
                        $reply = "<table><tr><th>Product</th><th>Quantity</th></tr>";
                        foreach($prods as $o){
                            $reply .= "<tr>";
                            $reply .= "<td>".$o->title."</td>";
                            $reply .= "<td>".$o->price."</td>";
                            $reply .= "</tr>";
                        }
                        $reply .= "</table>";
                    }else{
                        $reply = "Please use the search bar to search for the product";
                    }
                }else{
                    $reply = "Please use the search bar to search for the product";
                }
            }
            if($intent === "cash_on_delivery"){
                $reply = "Yes, we provide cash on delivery!";
            }
            if($intent === "home_delivery"){
                $reply = "Yes, we provide home delivery service!";
            }
            if($intent === "offers"){
                $reply = "Click on the link below to view "."<a href=\"offers.php\">current offers</a>";
            }
            if($intent === "payment_methods"){
                $reply = "You can pay after delivery. Other payment methods such as credit card, bkash are also available!";
            }
            if($intent === "credit_card"){
                $reply = "Yes, you can pay with your credit card!";
            }
            if($intent === "delivery_charge"){
                $reply = "We generally take 50tk as delivery charge inside Dhaka. Delivery charge for locations outside Dhaka is 100tk.";
            }
            if($intent === "refund_info"){
                $reply = "You can apply for refund within the next 24 hours of delivery.";
            }
            if($intent === "deliveryTime"){
                $reply = "It generally takes around 2/3 business days to get an order delivered";
            }
            if($intent === "cancel_order"){
                $reply = "An order can be cancelled before the order has been sent for shipping.";
            }
        }
        curl_close ($ch);  //close the connection
    }
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Chat Bot</title>
    <link rel="stylesheet" href="bot.css">
</head>

<body>
    <header>

    </header>
    <section>
        <div class="box">
           <h1>Ask me something</h1>
            <form action="" method="post">
                <input type="text" name="message">
                <input type="submit" value="Send" name="submit">
            </form>
            <div class="serverReply">
                <p><b> Reply: </b><?php echo $reply; ?> </p>
            </div>
        </div>
    </section>
</body>

</html>;