function clicked() {
    $.ajax({
        url: "action.php",
        method: "POST",
        data: {
            checkout_clicked: 1
        },
        success: function (data) {
            $("#get_category").html(data);

        }
    })
}
